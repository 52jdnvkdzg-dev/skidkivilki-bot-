from html import escape
def money(v):return "—" if v is None else f"{v:,.0f}".replace(","," ")+" ₽"
def format_deal(d):
    x=[f"🐺 <b>{escape(d.title)}</b>","",f"🔥 <b>−{d.discount}%</b>"]
    if d.old_price:x.append(f"💰 Было: <s>{money(d.old_price)}</s>")
    x.append(f"💸 Сейчас: <b>{money(d.new_price)}</b>")
    if d.store:x.append(f"🛍 {escape(d.store)}")
    if d.description:x+=["",f"📝 {escape(d.description[:300])}"]
    x+=["","⚡️ Цена и наличие могут измениться.","","Источник: Pepper.ru"]
    return "\n".join(x)
